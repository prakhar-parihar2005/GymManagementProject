package src;

import java.util.*;
import java.time.LocalDate;

public class AttendanceManager {

    private ArrayList<String> attendanceList;
    private Scanner sc;

    public AttendanceManager() {
        sc = new Scanner(System.in);
        attendanceList = FileHandler.loadAttendance();
    }

    public void markAttendance(MemberManager mgr) {
        System.out.print("Enter Member ID for attendance: ");
        int id = sc.nextInt();

        Member m = mgr.searchMember(id);

        if (m == null) {
            System.out.println("Member not found!");
            return;
        }

        String record = id + "," + LocalDate.now();
        attendanceList.add(record);

        FileHandler.saveAttendance(attendanceList);

        System.out.println("Attendance marked for " + m.getId());
    }

    public void viewAttendance() {
        if (attendanceList.isEmpty()) {
            System.out.println("No attendance recorded yet.");
            return;
        }

        for (String rec : attendanceList) {
            String[] data = rec.split(",");
            System.out.println("Member ID: " + data[0] + " | Date: " + data[1]);
        }
    }
}
