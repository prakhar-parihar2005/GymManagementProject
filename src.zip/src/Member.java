package src;

import java.io.Serializable;

public class Member implements Serializable {
    private int id;
    private String name;
    private String phone;
    private String membershipType;

    public Member(int id, String name, String phone, String membershipType) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.membershipType = membershipType;
    }

    public int getId() {
        return id;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setMembershipType(String type) {
        this.membershipType = type;
    }

    public void display() {
        System.out.println("-----------------------------------");
        System.out.println("ID            : " + id);
        System.out.println("Name          : " + name);
        System.out.println("Phone         : " + phone);
        System.out.println("Membership    : " + membershipType);
        System.out.println("-----------------------------------");
    }

    @Override
    public String toString() {
        return id + "," + name + "," + phone + "," + membershipType;
    }
}
