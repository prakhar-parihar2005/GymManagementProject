package src;

import java.util.*;
import java.io.*;

public class FileHandler {

    private static final String MEMBER_FILE = "data/members.txt";
    private static final String ATTENDANCE_FILE = "data/attendance.txt";

    public static ArrayList<Member> loadMembers() {
        ArrayList<Member> list = new ArrayList<>();

        try {
            File f = new File(MEMBER_FILE);
            if (!f.exists()) return list;

            BufferedReader br = new BufferedReader(new FileReader(f));
            String line;

            while ((line = br.readLine()) != null) {
                String[] arr = line.split(",");
                Member m = new Member(
                    Integer.parseInt(arr[0]),
                    arr[1],
                    arr[2],
                    arr[3]
                );
                list.add(m);
            }
            br.close();
        } catch (Exception e) {
            System.out.println("Error loading members.");
        }
        return list;
    }

    public static void saveMembers(ArrayList<Member> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(MEMBER_FILE))) {
            for (Member m : list) {
                pw.println(m.toString());
            }
        } catch (Exception e) {
            System.out.println("Error saving members.");
        }
    }

    public static ArrayList<String> loadAttendance() {
        ArrayList<String> list = new ArrayList<>();

        try {
            File f = new File(ATTENDANCE_FILE);
            if (!f.exists()) return list;

            BufferedReader br = new BufferedReader(new FileReader(f));
            String line;

            while ((line = br.readLine()) != null) {
                list.add(line);
            }
            br.close();
        } catch (Exception e) {
            System.out.println("Error loading attendance.");
        }
        return list;
    }

    public static void saveAttendance(ArrayList<String> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ATTENDANCE_FILE))) {
            for (String rec : list) {
                pw.println(rec);
            }
        } catch (Exception e) {
            System.out.println("Error saving attendance.");
        }
    }
}
