package src;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MemberManager memberManager = new MemberManager();
        AttendanceManager attendanceManager = new AttendanceManager();

        int choice;

        do {
            System.out.println("\n====== GYM MANAGEMENT SYSTEM ======");
            System.out.println("1. Add Member");
            System.out.println("2. View Members");
            System.out.println("3. Update Member");
            System.out.println("4. Delete Member");
            System.out.println("5. Mark Attendance");
            System.out.println("6. View Attendance");
            System.out.println("7. Exit");
            System.out.print("Enter Your Choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1: memberManager.addMember(); break;
                case 2: memberManager.viewMembers(); break;
                case 3: memberManager.updateMember(); break;
                case 4: memberManager.deleteMember(); break;
                case 5: attendanceManager.markAttendance(memberManager); break;
                case 6: attendanceManager.viewAttendance(); break;
                case 7: System.out.println("Exiting..."); break;
                default: System.out.println("Invalid choice!");
            }

        } while (choice != 7);

        sc.close();
    }
}
