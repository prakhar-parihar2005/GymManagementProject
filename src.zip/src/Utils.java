package src;

public class Utils {

    public static void printLine() {
        System.out.println("--------------------------------------");
    }
}
