package src;

import java.util.ArrayList;
import java.util.Scanner;

public class MemberManager {

    private ArrayList<Member> memberList;
    private Scanner sc;

    public MemberManager() {
        sc = new Scanner(System.in);
        memberList = FileHandler.loadMembers();
    }

    public void addMember() {
        System.out.print("Enter ID : ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Name : ");
        String name = sc.nextLine();

        System.out.print("Enter Phone : ");
        String phone = sc.nextLine();

        System.out.print("Membership Type (Monthly/Quarterly/Yearly) : ");
        String type = sc.nextLine();

        Member m = new Member(id, name, phone, type);
        memberList.add(m);

        FileHandler.saveMembers(memberList);
        System.out.println("Member added successfully!");
    }

    public void viewMembers() {
        if (memberList.isEmpty()) {
            System.out.println("No members found!");
            return;
        }
        for (Member m : memberList) {
            m.display();
        }
    }

    public void updateMember() {
        System.out.print("Enter ID to update : ");
        int id = sc.nextInt();
        sc.nextLine();

        for (Member m : memberList) {
            if (m.getId() == id) {
                System.out.print("New Phone: ");
                String phone = sc.nextLine();

                System.out.print("New Membership Type: ");
                String type = sc.nextLine();

                m.setPhone(phone);
                m.setMembershipType(type);

                FileHandler.saveMembers(memberList);
                System.out.println("Member updated.");
                return;
            }
        }
        System.out.println("Member not found!");
    }

    public void deleteMember() {
        System.out.print("Enter ID to delete : ");
        int id = sc.nextInt();

        Member target = null;
        for (Member m : memberList) {
            if (m.getId() == id) {
                target = m;
                break;
            }
        }

        if (target != null) {
            memberList.remove(target);
            FileHandler.saveMembers(memberList);
            System.out.println("Member removed.");
        } else {
            System.out.println("Member not found!");
        }
    }

    public Member searchMember(int id) {
        for (Member m : memberList) {
            if (m.getId() == id) {
                return m;
            }
        }
        return null;
    }
}
